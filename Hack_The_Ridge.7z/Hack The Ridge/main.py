import customtkinter as ctk 
import login_page
import Database.database_management 
import profile_window
from PIL import Image, ImageTk

dtb = Database.database_management.DatabaseManager()


ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("green")

background_image = Image.open('./Images/background.jpg')
people_icon_image = Image.open('./Images/people.png')
logo_image = Image.open('./Images/logo.png')
star_empty_icon = Image.open('./Images/empty_star.png')
star_filled_icon = Image.open('./Images/filled_star.png')

ctk_star_empty = ctk.CTkImage(light_image=star_empty_icon, size=(25, 25))
ctk_star_filled = ctk.CTkImage(light_image=star_filled_icon, size=(25, 25))

fg_colour = '#2A2A2A'
bg_colour = '#1F1F1F'
secondary_colour = '#B2B2B2'

header_font = ('Poppins', 50)
smaller_font = ('Poppings', 20)


class App(ctk.CTk):    
    def __init__(self):
        super().__init__()
        self.geometry("1280x720")
        self.title("IRHS Tutoring")
        self.resizable(False, False)
        self.login_page_status = None 
        self.profile_page_status = None

        self.people = []

        self.create_main_frames()
        self.load_background()
        
        self.create_login_frame()
        self.create_left_frame()
        self.create_search_frame()

        self.open_login_window()

    def search_tutors(self):

        courses = self.search_entry.get()

        courses = courses.split(',')

        self.people = dtb.rating_sorter(dtb.get_tutor_info(search_tags = courses))

        self.load_people()

    def create_main_frames(self):
        self.left_frame = ctk.CTkFrame(self, width=300, height=720)
        self.left_frame.grid(row=0, column=0, sticky='NW')

        self.middle_frame = ctk.CTkFrame(self, width=970, height=720)
        self.middle_frame.grid(row=0, column=1, sticky='NW')


    def create_login_frame(self):
        self.login_frame = ctk.CTkFrame(self.middle_frame, width=100, height=100)
        self.login_frame.grid(row=0, column=0, sticky='NW', padx=50, pady=50)
        
        self.title = ctk.CTkLabel(self.login_frame, text='Ridge\nTutoring', justify='left', font=header_font)
        self.title.grid(row=0, column=0)

        self.search_open_button = ctk.CTkButton(self.login_frame, text='Search for Tutors!', command=self.open_search_window)
        self.search_open_button.grid(row=1, column=0, pady=(30, 25), padx=25, sticky='W')

        self.login_for_tutor = ctk.CTkButton(self.login_frame, text = "Sign-Up", command = self.pop_login_page)
        self.login_for_tutor.grid(row = 2, column = 0, pady = 25, padx = 25, sticky = "W")

        self.login_frame.tkraise(self.background_image)

    def load_background(self):
        self.background_image = ctk.CTkLabel(self.middle_frame, text='', image=ctk.CTkImage(light_image=background_image, size=(1205, 720)))
        self.background_image.grid(row=0, column=0)

    def create_left_frame(self):
        self.logo_button = ctk.CTkLabel(self.left_frame, text='', image=ctk.CTkImage(light_image=logo_image, size=(75, 75)), bg_color=bg_colour)
        self.logo_button.grid(row=0, column=0)

        self.person_icon = ctk.CTkLabel(self.left_frame, text='', image=ctk.CTkImage(light_image=people_icon_image, size=(75, 75)), bg_color=bg_colour)
        self.person_icon.grid(row=1, column=0)

    def create_search_frame(self):

        self.search_frame = ctk.CTkFrame(self.middle_frame, fg_color=fg_colour, width=700, height=500)
        self.search_frame.grid(row=0, column=0)

        self.title_label = ctk.CTkLabel(self.search_frame, fg_color=fg_colour, text='Tutor Area')
        self.title_label.grid(row=0, column=0, sticky='ew', columnspan=3)

        self.search_label = ctk.CTkLabel(self.search_frame, fg_color=fg_colour, text='Search for Tutor!')
        self.search_label.grid(row=1, column=0)

        self.search_entry = ctk.CTkEntry(self.search_frame, fg_color=fg_colour, placeholder_text='Course Codes', width = 200)
        self.search_entry.grid(row=1, column=1)

        self.back_button = ctk.CTkButton(self.middle_frame, width = 150, height = 50, command = self.open_login_window, text = "Back")
        self.back_button.grid(row = 0, column = 0, sticky = "ne", pady = 10, padx = 10)

        self.scroll_frame = ctk.CTkScrollableFrame(self.search_frame, fg_color=bg_colour)
        self.scroll_frame.grid(row=2, column=0, ipadx=400, ipady=150, columnspan=3)
        
        self.people = []
        self.load_people()

        self.button_frame = ctk.CTkFrame(self.middle_frame)
        self.button_frame.grid(row=0, column=0, sticky='s', pady=50)

        self.search_submit = ctk.CTkButton(self.button_frame, text = "Search!", command = self.search_tutors)
        self.search_submit.grid(row = 1, column = 0)

        self.button_frame.tkraise(self.search_frame)
        
    def load_people(self):
        self.people_frames = []
        self.selected_person_var = ctk.StringVar()

        people_ratings = [self.people[i][4] for i in range(len(self.people))]
        for i in range(len(self.people)):
            person_frame = ctk.CTkFrame(self.scroll_frame)

            name_label = ctk.CTkLabel(person_frame, text=f'\n{self.people[i][0]}', width=500, anchor='w')
            name_label.grid(row=0, column=0, padx=25,sticky='w')

            view_button = ctk.CTkRadioButton(person_frame, text='View Profile', value=i, variable=self.selected_person_var, command=self.view_profile)
            view_button.grid(row=0, column=1, padx=25)

            stars = []

            for j in range(5):
                star_label = ctk.CTkLabel(person_frame, text='', image=ctk_star_empty if j + 1 > people_ratings[i] else ctk_star_filled)
                star_label.grid(row=0, column=j + 2, sticky='e')
                
                stars.append(star_label)

            self.people_frames.append(person_frame)
            self.people_frames[i].grid(row=i, column=0)

    def open_search_window(self):
        self.button_frame.tkraise(self.login_frame)
        self.search_frame.tkraise(self.login_frame)
        self.background_image.tkraise(self.login_frame)

    def open_login_window(self):
        self.login_frame.tkraise(self.search_frame)
        self.button_frame.tkraise(self.search_frame)
        self.background_image.tkraise(self.button_frame)

    def view_profile(self):
        index = int(self.selected_person_var.get())

        if self.profile_page_status is None or not self.profile_page_status.winfo_exists():
            self.profile_page_status = profile_window.ProfileWindow(self, self.people[index])
        else:
            self.profile_page_status.focus()

    def pop_login_page(self):        
        if self.login_page_status is None or not self.login_page_status.winfo_exists():
            self.login_page_status = login_page.LoginPageWindow(self)
        else:
            self.login_page_status.focus()

#  widget.tkraise(self.background_image)


main_root = App()

main_root.mainloop()