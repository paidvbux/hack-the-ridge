import customtkinter as ctk 
import Database.database_management

dtb = Database.database_management.DatabaseManager()

header_font = ('Poppins', 50)
smaller_font = ('Poppings', 20)


class LoginPageWindow(ctk.CTkToplevel):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.geometry("600x600")
        self.title("Login Page")

        self.window_title = ctk.CTkLabel(self, text = "Login Window", font = header_font)
        self.window_title.pack(pady = 10)

        self.fullname = ctk.CTkEntry(self, placeholder_text = 'Full Name', width = 300, height = 50, font = smaller_font)
        self.fullname.pack(pady = 10)

        self.phone = ctk.CTkEntry(self, placeholder_text = 'Phone #', width = 300, height = 50, font = smaller_font)
        self.phone.pack(pady = 10)

        self.username = ctk.CTkEntry(self, placeholder_text = 'Email', width = 300, height = 50, font = smaller_font)
        self.username.pack(pady = 10)

        self.password = ctk.CTkEntry(self, placeholder_text = "Password", width = 300, height = 50, font = smaller_font, show = "•")
        self.password.pack( pady = 10)

        self.courses = ctk.CTkEntry(self, placeholder_text = "Courses # Sperated By Commas", width = 300, height = 50, font = smaller_font)
        self.courses.pack( pady = 10)

        self.submit = ctk.CTkButton(self, text = "Sign-up", width = 250, height = 50, font = smaller_font, command = self.signup_function)
        self.submit.pack(pady = 10)
        
    def signup_function(self):

        def cleanup(x):
            return x.strip()

        name = self.fullname.get()
        phone_num = self.phone.get()
        email = self.username.get()
        password = self.username.get()
        tags = str([cleanup(i) for i in self.courses.get().split(",")]).replace("'",'"')
        rating = 3
        str_tags = str(tags).replace("'", '"')

        str_tags = f"'{str_tags}'"


        dtb.add_to_database(
            tutor_info = (name, phone_num, email, tags, rating, password)
        )

        dtb.commit_changes()
        dtb.close_database()
