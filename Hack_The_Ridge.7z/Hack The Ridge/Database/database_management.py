import sqlite3
from os import remove 
import random

class DatabaseManager():
    def __init__(self):
        self.conn = sqlite3.connect("Database/tutors.db")
        self.c = self.conn.cursor()

    def close_database(self) -> None:
        self.conn.close()

    def commit_changes(self) -> None:
        self.conn.commit()

    def create_table(self) -> None:

        self.c.execute("""CREATE TABLE tutors (
            name text,
            phone text,
            email text,
            courses text,
            rating integer,
            password text
        )""")

    def add_to_database(self, tutor_info : tuple) -> None:

        name = tutor_info[0]
        phone = tutor_info[1]
        email = tutor_info[2]
        tags = tutor_info[3]
        rating = tutor_info[4]
        password = tutor_info[5]

        self.c.execute(f"INSERT INTO tutors VALUES ('{name}', '{phone}', '{email}', '{tags}', {rating}, '{password}')")

    def rating_sorter(self, list_of_tutors : list) -> list:

        if not list_of_tutors:
            return []

        search_query = ""

        for i in range(len(list_of_tutors)):
            name = list_of_tutors[i]
            if i == len(list_of_tutors) - 1:
                search_query += f"email = '{name}' "
            else:
                search_query += f"email = '{name}' OR "

        self.c.execute(f"SELECT * FROM tutors WHERE {search_query}")

        items = self.c.fetchall()

        new_items = sorted(items, key = lambda tutor : tutor[4])[::-1]

        return new_items 
    
    
    def get_tutor_info(self, search_tags : list) -> None:
        '''Return the list of emails for each of the tutors that are eligible that teach this course'''

        self.c.execute("SELECT * FROM tutors")

        items = self.c.fetchall()

        result = []

        for i in range(len(items)):
            contact_of_tutor = items[i][2]
            contact_tags = items[i][3][1:-1].replace('"', "").split(', ')

            if any(x in contact_tags for x in search_tags):
                result.append(contact_of_tutor)

        return result 

# DATATYPES:
# NULL
# INTEGER
# TEXT
# REAL 
# BLOB 

# Remove after first run 
# Only for sample data
# You can comment out everything here after you run for the first time
remove("Database/tutors.db")

# Initialize database 
dtb = DatabaseManager()
dtb.create_table()

# Sample Data
dtb.add_to_database(('Tugrul Guran', '123-456-7890', 'tugrulguran@gmail.com', '["ICS3U1", "MHF4U"]', 4, "Password123"))
dtb.add_to_database(('Shray Kumar', '234-567-8901', 'shraykumar@gmail.com', '["FSF3U", "SCH3U"]', 3, "abcdefg789"))
dtb.add_to_database(('Jeric Jiang', "345-678-9012", "jericwang@yahoo.com", '["SPH3U", "MCV4U", "MCR3U]', 4, "qwerty456"))
dtb.add_to_database(('David Smith', '805-243-4057', 'david.smith@gmail.com', '["ICS3M"]', 4, "letmein987", "[0,1,1,1,0,0,1]"))
dtb.add_to_database(('Eva Lee', '385-382-4745', 'eva.lee@gmail.com', '["MPM1D", "TGJ2O", "BAT4M", "MHF4U"]', 5, "123abcxyz"))
dtb.add_to_database(('David Brown', '252-946-9123', 'david.brown@gmail.com', '["ENG2P", "MCF3M", "ICS3M", "ICS4U"]', 3, "p@ssword321"))
dtb.add_to_database(('Eva Smith', '201-376-5888', 'eva.smith@gmail.com', '["SNC2D"]', 3, "ilovecoding"))
dtb.add_to_database(('Bob Smith', '502-917-9233', 'bob.smith@gmail.com', '["ICS4U"]', 4, "soccer1234"))
dtb.add_to_database(('David Lee', '694-590-7421', 'david.lee@gmail.com', '["ENG2P", "BAT4M", "ENG4U", "MHF4U"]', 3, "easyas123"))
dtb.add_to_database(('Alice Brown', '856-860-6614', 'alice.brown@gmail.com', '["ICS3M"]', 3, "8765abcd"))
dtb.add_to_database(('Eva Leek', '700-768-9068', 'eva.leek@gmail.com', '["TGJ2O"]', 2, "welcome567"))
dtb.add_to_database(('David Johnson', '564-173-1151', 'david.johnson@gmail.com', '["MPM1D", "MHF4U", "ICS3M"]', 4, "sunshine789"))
dtb.add_to_database(('Alice Brown', '856-860-6614', 'alice.brown@gmail.com', '["ICS3M"]', 3, "cheeseburger"))



# dtb.get_tutor_info(search_tags = ['MHF4U']) --> How to search for a tag
# dtb.rating_sorter(results) --> Orders tutors by rating from 5 to 1

dtb.commit_changes()
dtb.close_database()