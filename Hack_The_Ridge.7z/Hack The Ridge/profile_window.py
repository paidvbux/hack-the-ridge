import customtkinter as ctk 
from PIL import Image, ImageTk

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("green")

header_font = ('Poppins', 40)
smaller_font = ('Poppings', 20)

star_empty_icon = Image.open('./Images/empty_star.png')
star_filled_icon = Image.open('./Images/filled_star.png')

ctk_star_empty = ctk.CTkImage(light_image=star_empty_icon, size=(25, 25))
ctk_star_filled = ctk.CTkImage(light_image=star_filled_icon, size=(25, 25))

class ProfileWindow(ctk.CTkToplevel):

    def __init__(self, master, info):
        super().__init__()

        self.geometry("600x600")
        self.title(f"{info[0]}'s Profile")

        self.name_label = ctk.CTkLabel(self, text=f"{info[0]}'s Profile", font=('Poppins', 50), bg_color='green', width=600, anchor='w')
        self.name_label.grid(row=0, column=0, columnspan=10)

        self.phone_title = ctk.CTkLabel(self, text=f'Phone #', font=header_font, justify='left')
        self.phone_title.grid(row=1, column=0, columnspan=5)

        self.phone_label = ctk.CTkLabel(self, text=info[1], font=smaller_font, justify='left')
        self.phone_label.grid(row=2, column=0, columnspan=5, pady=(5, 25))
        
        self.email_title = ctk.CTkLabel(self, text=f'Email', font=header_font, justify='left')
        self.email_title.grid(row=3, column=0, columnspan=5)

        self.email_label = ctk.CTkLabel(self, text=info[2], font=smaller_font, justify='left')
        self.email_label.grid(row=4, column=0, columnspan=5, pady=(5, 25))
        

        courses_text = self.generate_course_text(info[3])

        self.courses_title = ctk.CTkLabel(self, text='Courses Taught', font=header_font, justify='left')
        self.courses_title.grid(row=1, column=6)

        self.courses_label = ctk.CTkLabel(self, text=f'\n{courses_text}', font=smaller_font, justify='left')
        self.courses_label.grid(row=2, column=6, rowspan=10)

        for i in range(5):
            star = ctk.CTkLabel(self, text='', image=ctk_star_empty if i + 1 > info[4] else ctk_star_filled)
            star.grid(row=5, column=i)

    def generate_course_text(self, info):
        return info.replace('"','')[1:-1]

